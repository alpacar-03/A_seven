"""
大模型接口包
~~~~~~~~~~

包含与DeepSeek大模型交互的接口实现。
"""

from .DeepSeek import Deepseek_API

__all__ = ['Deepseek_API']