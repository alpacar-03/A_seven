"""
样式包
~~~~~

包含应用程序的主题和样式定义。
"""

from .theme import Theme

__all__ = ['Theme']



