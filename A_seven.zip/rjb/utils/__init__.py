"""
工具包
~~~~~

包含各种实用工具函数。
"""

from .file_utils import read_file_content

__all__ = ['read_file_content'] 